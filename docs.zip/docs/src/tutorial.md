```@meta
CurrentModule = TextAssociations
```

# TextAssociations

Documentation for [TextAssociations](https://github.com/atantos/TextAssociations.jl).

## Basics
